package reva.Actions;

public class RevaActionCancelled extends Exception {
    public RevaActionCancelled(String message) {
        super(message);
    }
}
