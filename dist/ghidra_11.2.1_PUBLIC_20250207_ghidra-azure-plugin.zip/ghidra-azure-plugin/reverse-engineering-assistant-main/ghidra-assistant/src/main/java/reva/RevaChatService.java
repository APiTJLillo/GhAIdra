package reva;

public interface RevaChatService {
    public String revaChat(String message);
    public void blockUntilConnected();
}
