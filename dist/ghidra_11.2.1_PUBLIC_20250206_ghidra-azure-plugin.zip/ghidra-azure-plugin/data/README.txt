This directory contains data files for the Ghidra Azure AI Plugin.

The plugin may store cached results, temporary data, or other generated files in this directory during operation. This helps optimize performance and maintain state between Ghidra sessions.

Note: This directory must be preserved in the plugin distribution for proper functionality.
