The "os/win_x86_64" directory is intended to hold MS Windows native binaries (.exe)
which this module is dependent upon.   This directory may be eliminated for a specific 
module if native binaries are not provided for the corresponding platform.
