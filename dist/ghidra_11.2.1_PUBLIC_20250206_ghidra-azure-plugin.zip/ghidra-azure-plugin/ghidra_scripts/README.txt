This directory contains Ghidra scripts used by the plugin.
